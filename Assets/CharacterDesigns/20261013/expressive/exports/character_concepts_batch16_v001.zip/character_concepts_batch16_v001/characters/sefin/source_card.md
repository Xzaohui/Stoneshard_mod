---
title: "人物_DEN-NPC-SEF_瑟芬·网"
id: CITY-NPC-DEN-NPC-SEF
type: character
status: draft
canon: mod-original
baseline: "0.9.4.25-modbranch"
updated: 2026-10-12
tags: [stoneshard, city-campaign, S63]
aliases: []
---

# 人物_DEN-NPC-SEF_瑟芬·网

**工作**：原村渔者。

**起点与转折**：要家回岸上，却曾替驻点选可优先回迁的名单。

城市：[[聚落_DEN_丹布里]]

关联篇章：[[台本_CM-DEN_潮水退去以后]]

此卡概括弧线；实际台词、路线代价与去留见篇章台本。只有亲历、本人授权或有限回执可解锁回应，不能代表全国阵营。熟悉玩家不抵消拒绝/死亡/保密；退出后保已发生的责任记录。

[[城市与聚落设计总索引]]

丹布里与曼郡的逐角色对白、实际接收与来源交叉见[[丹布里与曼郡人物演出审查]]；S81为Mod原创初稿，未导入游戏。
