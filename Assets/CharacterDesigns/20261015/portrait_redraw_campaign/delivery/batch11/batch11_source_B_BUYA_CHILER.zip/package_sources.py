#!/usr/bin/env python3
"""Build ordinary audited source ZIPs only after independent QA has frozen batch11."""
from pathlib import Path
from datetime import datetime, timezone
import base64, hashlib, json, shutil, subprocess, sys, tempfile, zipfile, zlib
D=Path(__file__).resolve().parent; R=D.parent.parent; REPO=R.parents[3]
ORDER=['risha','milei','buya','chiler']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p,x): p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
qa=R/'independent_qa/batch11'
gate=json.loads((D/'freeze_gate.json').read_text()); assert gate['approved_to_package'] is True
selected=json.loads((D/'selected_delivery_manifest.json').read_text())
for x in selected['characters']:
    ref=next(y for y in gate['characters'] if y['slug']==x['actor'])
    assert (R/ref['selected_portrait']).resolve()==(R/x['source']).resolve()
    assert ref['selected_sha256']==x['source_sha256']==sha(R/x['source'])==sha(D/x['delivery_file'])
visual=json.loads((D/'delivery_visual_QA.json').read_text())
assert visual['actually_viewed_via_view_image'] and visual['board_sha256']==sha(D/selected['board']['file'])
for name, expected in gate['qa_files'].items(): assert sha(qa/name)==expected,name
for line in (qa/'SHA256SUMS.txt').read_text().splitlines():
    h,rel=line.split('  ',1); assert sha(qa/rel)==h,rel
original_hashes={}; production_checks=[]
for c in ORDER:
    root=R/c; m=json.loads((root/'manifest.json').read_text())
    independent=next(x for x in gate['characters'] if x['slug']==c)
    assert sha(root/'manifest.json')==independent['production_manifest_sha256']
    sums=root/('SHA256SUMS.txt' if (root/'SHA256SUMS.txt').exists() else 'SHA256SUMS')
    sum_rows={}
    for line in sums.read_text().splitlines():
        h,rel=line.split('  ',1); assert sha(root/rel)==h,(c,rel);sum_rows[rel]=h
    actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and p.name not in ('SHA256SUMS.txt','SHA256SUMS')}
    assert actual==set(sum_rows),('SHA inventory mismatch',c,actual^set(sum_rows))
    if 'files' in m:
        for item in m['files']: assert sha(root/item['path'])==item['sha256'] and (root/item['path']).stat().st_size==item['bytes'],(c,item['path'])
        assert actual-{'manifest.json'}=={x['path'] for x in m['files']} and len(actual)-1==len(m['files']),c
    source_checks=[]
    source_data=json.loads((root/'sources/source_manifest.json').read_text())
    source_rows=source_data if isinstance(source_data,list) else source_data.get('items',source_data.get('sources',source_data.get('source_files',source_data.get('files',[]))))
    assert source_rows,c
    for item in source_rows:
        p=item.get('original_path',item.get('source',item.get('path',item.get('source_path')))); s=item.get('snapshot',item.get('copy',item.get('local_copy',item.get('snapshot_path'))))
        assert sha(REPO/p)==item['sha256']==sha(root/s),(c,p)
        source_checks.append({'original':p,'snapshot':s,'sha256':item['sha256'],'original_and_snapshot_identical':True})
    returns=list((root/'tool_returns').glob('portrait_v[12].json')); assert len(returns)==m.get('generation_calls',m.get('generation_calls_completed',m.get('generation',{}).get('attempts')))
    for retpath in returns:
        data=json.loads(retpath.read_text()); raw=root/'raw'/f'{retpath.stem}_raw_imagegen.png'
        assert raw.read_bytes()==base64.b64decode(data['image_url'].split(',',1)[1])
    for p in sorted(root.rglob('*')):
        if p.is_file():
            assert not p.is_symlink(),p
            original_hashes[p.relative_to(R).as_posix()]=sha(p)
    production_checks.append({'actor':c,'manifest_sha256':sha(root/'manifest.json'),'sha256sums_valid':True,'manifest_inventory_valid':True,'raw_toolreturn_byte_identical':True,'source_checks':source_checks})
for p in sorted(qa.rglob('*')):
    if p.is_file(): original_hashes[p.relative_to(R).as_posix()]=sha(p)
# References remain path/hash only; commercial baseline pixels are never copied.
commercial=REPO/'Assets/CharacterDesigns/20261015/native_style_pilot/mara/sources/user_style_reference.png'
excluded=[{'original_path':commercial.relative_to(REPO).as_posix(),'sha256':sha(commercial),'bytes':commercial.stat().st_size,'included_bytes':False,'role':'Campaign background comparative reference containing native commercial art; not a direct input asserted for this batch.'}]
js(D/'DELIVERY_EXCLUSIONS.json',{'commercial_reference_pixels_included':False,'items':excluded,'policy':'Only the four production folders and their independently generated QA plus delivery files enter these packages. No commercial native-reference image or source sprite atlas is included. The original manifests and tool calls are retained unchanged.'})
js(D/'production_source_verification.json',{'verified_utc':datetime.now(timezone.utc).isoformat(),'production_checks':production_checks,'all_pass':True})
common=['README_交付说明.md','DELIVERY_EXCLUSIONS.json','verify_source_package.py','selected_delivery_manifest.json','delivery_visual_QA.json','freeze_gate.json','production_source_verification.json','build_delivery.py','package_sources.py','reproduce_candidates.py',selected['board']['file']]+[x['delivery_file'] for x in selected['characters']]
results=[]
for suffix,characters in [('A_RISHA_MILEI',['risha','milei']),('B_BUYA_CHILER',['buya','chiler'])]:
    snap=D/'source_snapshots'/suffix; assert not snap.exists(),'Refuse overwrite of existing snapshot'; snap.mkdir(parents=True)
    origins={}
    for c in characters:
        for p in sorted((R/c).rglob('*')):
            if not p.is_file(): continue
            rel=p.relative_to(R).as_posix(); dst=snap/'portrait_redraw_campaign'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dst)
            assert sha(dst)==original_hashes[rel]
            origins[dst.relative_to(snap).as_posix()]={'kind':'production','original':rel,'sha256':original_hashes[rel]}
    for p in sorted(qa.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(R).as_posix(); dst=snap/'portrait_redraw_campaign'/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dst)
        assert sha(dst)==original_hashes[rel]
        origins[dst.relative_to(snap).as_posix()]={'kind':'independent_qa','original':rel,'sha256':original_hashes[rel]}
    for name in common:
        shutil.copyfile(D/name,snap/name); origins[name]={'kind':'delivery','original':name,'sha256':sha(D/name)}
    with tempfile.TemporaryDirectory(prefix='batch11-reproduce-') as tmp:
        cmd=[sys.executable,str(snap/'reproduce_candidates.py'),'--output',str(Path(tmp)/'new-output')]
        run=subprocess.run(cmd,check=True,capture_output=True,text=True)
        report=json.loads(run.stdout); assert report['all_pass']
    js(snap/'portable_reproduction_verification.json',report)
    origins['portable_reproduction_verification.json']={'kind':'portable_reproduction','sha256':sha(snap/'portable_reproduction_verification.json')}
    files=[]
    excluded_hashes={x['sha256'] for x in excluded}
    for p in sorted(snap.rglob('*')):
        if not p.is_file(): continue
        b=p.read_bytes(); h=hashlib.sha256(b).hexdigest(); assert h not in excluded_hashes
        files.append({'path':p.relative_to(snap).as_posix(),'bytes':len(b),'sha256':h,'crc32':f'{zlib.crc32(b)&0xffffffff:08x}','source':origins[p.relative_to(snap).as_posix()]})
    js(snap/'package_inventory.json',{'package':suffix,'characters':characters,'commercial_reference_pixels_included':False,'self_inventory_excluded':['package_inventory.json','PACKAGE_SHA256SUMS.txt'],'files':files})
    (snap/'PACKAGE_SHA256SUMS.txt').write_text(''.join(f'{x["sha256"]}  {x["path"]}\n' for x in files)+f'{sha(snap/"package_inventory.json")}  package_inventory.json\n',encoding='utf-8')
    out=D/f'batch11_source_{suffix}.zip'; assert not out.exists(),'Refuse replacing archive'
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(snap.rglob('*')):
            if p.is_file(): z.write(p,p.relative_to(snap).as_posix())
    assert out.stat().st_size<18*1024*1024
    run=subprocess.run([sys.executable,str(D/'verify_source_package.py'),str(out)],check=True,capture_output=True,text=True)
    checks=json.loads(run.stdout)
    with tempfile.TemporaryDirectory(prefix='batch11-zip-replay-') as tmp:
        folder=Path(tmp)/'extracted'; folder.mkdir()
        with zipfile.ZipFile(out) as z: z.extractall(folder)
        replay=subprocess.run([sys.executable,str(folder/'reproduce_candidates.py'),'--output',str(Path(tmp)/'reproduced')],check=True,capture_output=True,text=True)
        assert json.loads(replay.stdout)==report
    results.append({'file':out.name,'bytes':out.stat().st_size,'MiB':round(out.stat().st_size/1024**2,3),'sha256':sha(out),'crc_all_pass':True,'member_hash_all_pass':True,'actual_extracted_zip_reproduction_all_pass':True,'reproduction':report,'checks':checks})
for rel,h in original_hashes.items(): assert sha(R/rel)==h,('Frozen source changed during packaging',rel)
js(D/'package_verification.json',{'verified_utc':datetime.now(timezone.utc).isoformat(),'production_stable_during_packaging':True,'all_pass':True,'packages':results})
attachments=[selected['board']['file']]+[x['delivery_file'] for x in selected['characters']]+[x['file'] for x in results]; assert len(attachments)<=10
js(D/'upload_request.json',{'uploads':[{'local_path':str(D/n),'purpose':'create_library_file','library_artifact_type':'image' if n.endswith('.png') else 'other'} for n in attachments]})
print(json.dumps({'attachments':attachments,'packages':[{k:v for k,v in x.items() if k not in ['checks','reproduction']} for x in results],'production_stable':True},ensure_ascii=False,indent=2))
