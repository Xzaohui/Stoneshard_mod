# 第一组五人头像重绘：独立 QA

日期：2026-10-15 UTC。范围仅限本批 Mia、ENA、NARA、NELL、SEL；不修改生产图、旧资产、人物卡或游戏代码，不提交/推送。

## 最终结论

**五张均为 candidate，可作为头像风格候选展示。本批没有 native_final 或整体原生美术 pass。** 技术尺寸、色数、透明通道与可复现导出通过，不等于原生逐像素创作完成，也不代表用户已经认可这些新图或游戏运行验收。

| 角色 | 选用文件（相对本轮根目录） | 等级 | 可见RGB | 有效尺寸 |
|---|---|---|---:|---|
| 米娅 / Mia | `mia/candidates/portrait_v2_maxcoverage_74x100_candidate.png` | candidate | 32 | 73×100 |
| 艾娜 / ENA | `ena/candidates/portrait_v2_74x100_candidate.png` | candidate | 29 | 74×100 |
| 纳拉 / NARA | `nara/candidates/portrait_v2_74x100_candidate.png` | candidate | 30 | 74×100 |
| 妮尔 / NELL | `nell/candidates/portrait_v2_74x100_candidate.png` | candidate | 32 | 74×97 |
| 塞尔 / SEL | `sel/candidates/portrait_v2_mediancut_74x100_candidate.png` | candidate | 32 | 73×99 |

所有选稿画布均为74×100、RGBA、alpha仅0/255、透明RGB残留为0。≤32色仅本批临时上限。每人初稿＋一次集中修订，共10次生图；Mia与SEL各有一次不改变形状的量化导出对照，非追加生图。

## 依据与实际审查

- 读取根AGENTS、design/AGENTS、五张当前权威独立人物卡及精确派工文件。派工34条路径/哈希独立复核一致。ENA采用NPC-N-ENA独立卡，避开旧表情源混入的MAE-S03同名人物卡。
- 通过view_image实际查看五人旧母版、用户风格拼图、Mara v2、Iwo v1、Leiya v2 MAXCOVERAGE、Tore v1；旧母版只锁身份/服装，不沿用娃娃比例。
- 实际查看全部10张新raw、对应1x/8x预览及两份量化对照，并查看本QA五人1x/4x横向比较。图像查看路径与哈希在review_basis.json。
- 独立重算尺寸、可见色、alpha、透明RGB、有效包围盒、4/8连通分量和SHA；未运行生产者脚本。独立实现其已记录的导出算法并比对全部12份派生，逐RGBA像素一致。
- 全部10张raw与完整工具返回中解码的图像、工具输出提示所指generated_images原文件字节一致。完整来源及最终SHA见final_selection.json、measurements.json。

## 原始图与导出诚实口径

9张raw为1079×1458，SEL v2为1079×1457；raw可见RGB从32,371至54,606，全部256级alpha。它们不是74×100严格原生像素PNG。全画布NEAREST→alpha阈值128→可见采样RGB生成32色无抖动色板→透明RGB归零，可精确复建目标文件；这只证明技术派生可复现，不能证明raw使用统一逻辑像素格。

自动量化的两种方法各有取舍：Mia MEDIANCUT把小面积披肩压近灰色，MAXCOVERAGE保住暗青；SEL MAXCOVERAGE把原图细微颜色差放大成盐斑，MEDIANCUT使皮肤重新连贯。两对导出的alpha逐像素完全相同，未局部涂色或补形。Mia按G>R+10且B>R+10的诊断，青色像素从96到314；该判据只说明此处身份色损失，不是风格通过标准。

ENA v2保留3像素独立侧发簇(3,74)、(3,75)、(4,75)，其余4张最终候选各为单一8连通前景。断簇和近似色/单像素色提示仍需终稿手工收口，不因为二值alpha合格掩盖。

## 米娅 / Mia：candidate

v2去上挑眼尾、压低眼睑、扩大脸部并缩短颈部，较长窄脸、鼻翼与颧面仍清楚。低辫和暗青披肩/米白布衣对应旧身份，疲惫而自主的三十多岁患者读感成立。

v2 MEDIANCUT把小面积暗青披肩压成近灰青，选MAXCOVERAGE机械对照恢复识别色；不是第三次生图。

保留局限：眼白仍稍亮，顶发仍有平行纹，MAXCOVERAGE的头发色阶有灰褐倾向；自动材质色阶未人工收口。

## 艾娜 / ENA：candidate

v2构图收紧、鼻翼变钝宽，嘴更平而坚定；米色头巾和棕衣清楚，能读到务实忧虑而非通用甜笑。成年面部不再沿用旧娃娃眼。

选v2 MEDIANCUT；唯一生图修订已用完。当前断簇不妨碍身份/表情读形，但阻止宣称像素终稿完成。

保留局限：眼白与上抬忧眉仍偏强，头巾占幅与平行纵褶偏多；1x仍可看出与Mia相近的颧面安排。侧发有3像素八连通独立簇(3,74)、(3,75)、(4,75)，保留未补画。

## 纳拉 / NARA：candidate

v2面中、下颌与鼻翼更宽，短须连块、颈部收短，暗锈工装边保留。与Tore的偏长窄脸拉开，约四十岁修理工和先看出口的戒备可辨。

选v2 MEDIANCUT；宽脸/发簇改善较v1明确，无需追加生成。

保留局限：头顶仍有短尖与内部平行分带，须内有小阶梯块，自动色板仍有近似色；表情偏紧张但未到咆哮恶人。

## 妮尔 / NELL：candidate

v2开额、后梳低盘发、去颊卷，把她与Mia低辫/Mara松发区分；脸部更大、颈更短。长鼻/高颧、眼下疲惫和闭口戒备保住四十多岁劳务书记的读感。

选v2 MAXCOVERAGE，深蓝/米色领口身份保持；唯一修订后不再生图。

保留局限：眼白仍偏亮、外眼角黑线较硬，顶发还有平行带；嘴形未完全达到短薄克制。自动色板有少量单像素色，不是人工材料色阶。

## 塞尔 / SEL：candidate

v2灰短发与灰全须合大块、缩颈，仅保窄锈红/炭围裙边，五十岁左右老工坊师傅的身份最明确。MEDIANCUT消除额头鼻梁颧面的离群亮斑，体积更连贯。

v2 MAXCOVERAGE有可见盐斑，因此只作保留的非选用导出；选同raw、同NN、同alpha的MEDIANCUT机械对照，不增加生图。

保留局限：厚眉心与下垂嘴仍偏严厉，眼白对比略高，灰须/发仍有阶梯与自动近似色；只达候选，不以灰发等同完整年龄演出。

## 整组一致性与展示边界

横向比较中，低辫患者、米头巾家属、宽脸短须维修工、开额低髻书记、灰须老工坊主可分辨，修订明显降低初稿同脸与长颈问题。仍共享偏左三分之四角度、类似的颧面高光和部分眼型习惯；差异化够评审，不宜称整组原生美术终审通过。

主展示只使用五个选稿。必须标注“74×100、NN＋量化派生、candidate、未接入游戏”。v1、Mia v2 MEDIANCUT、SEL v2 MAXCOVERAGE保留为过程证据，不能混算新增角色或通过终稿。源包保留提示词、完整工具返回、raw、导出方法和QA；不要捆绑商业原生参考或含它们的拼图。

## 最终候选 SHA-256

- 米娅 / Mia：`2ad2319059c0f738cf4df310df24d2f65fad6c27f14f87cd03f7f59e01cec6d9`
- 艾娜 / ENA：`86c117a0e4d938cd0a817c97f5f4d6d105dbd725d25dac2cd25eb13190f98a5c`
- 纳拉 / NARA：`3fc1469022e4cc1adeb4178f7a57f2b82205b55a50940d99db9984483c48c9e3`
- 妮尔 / NELL：`61432a2a42be76b84ce24ba965395232e548925fea050d08a7451bf53edfd0aa`
- 塞尔 / SEL：`c263c69dd36728824a81c4105ee412447bd0589b05ab16133f540783a2935d8c`

## 复查方式

在仓库根目录运行本目录的measure_images.py与check_manifests.py，只更新本QA目录中的只读实测结果。reproduction_config.json明确每份派生的raw、量化方法与可见像素色板规则；不运行或覆盖生产者输出。冻结后的生产manifest、SHA256SUMS、选稿指针与来源哈希复核记录见manifest_checks.json。
