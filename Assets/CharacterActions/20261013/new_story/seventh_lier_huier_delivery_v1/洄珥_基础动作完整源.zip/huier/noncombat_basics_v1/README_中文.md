# 洄珥基础动作制作记录

人物 FX-CV6，已有角色。本次计划2张独立全身非战斗姿态，合格2张。

- huier_A1_raise_right_hand_brow_shade_v1
- huier_A2_two_hand_settle_carry_strap_v1

raw保留完整工具返回（含原图payload）与原PNG；prompts保留逐字提示词和实际参数；sources保留原始来源SHA、复制来源、冻结brief与计划门审；review含真实浅深合成、独审与作者检查。脚本仅清理alpha≤8及透明隐藏RGB、整图nearest等比排版，不修改人体或道具。

非战斗静态演出提案，不代表任务结果、完整动画、目标像素网格、装备拆层、碰撞或游戏运行通过。未修改母图、表情、角色卡、游戏或存档，未Git、上传或发送。
