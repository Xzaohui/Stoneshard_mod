---
title: "人物_RAT-NPC-IME_伊默·栅"
id: CITY-NPC-RAT-NPC-IME
type: character
status: draft
canon: mod-original
baseline: "0.9.4.25-modbranch"
updated: 2026-10-12
tags: [stoneshard, city-campaign, S63]
aliases: []
---

# 人物_RAT-NPC-IME_伊默·栅

**工作**：受灾家庭后人。

**起点与转折**：要认损失，却把现时伤害也说成旧怪物。

城市：[[聚落_RAT_拉滕]]

关联篇章：[[台本_CM-RAT_兽死之后]]

此卡概括弧线；实际台词、路线代价与去留见篇章台本。只有亲历、本人授权或有限回执可解锁回应，不能代表全国阵营。熟悉玩家不抵消拒绝/死亡/保密；退出后保已发生的责任记录。

[[城市与聚落设计总索引]]

粮村与纪念地域的逐角色对白、两户女儿、现时护栏和有限给付见[[奥斯布鲁克与拉滕人物演出审查]]；S83为Mod原创初稿，未导入游戏。
