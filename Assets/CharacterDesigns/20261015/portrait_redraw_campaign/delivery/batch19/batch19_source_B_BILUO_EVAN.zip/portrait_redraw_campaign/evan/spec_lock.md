# evan 头像重绘锁定

{
  "actor_id": "KOR-NPC-EV",
  "character": "埃文·行",
  "checked_utc": "2026-10-15T11:03:25.697753+00:00",
  "identity_conflict": false,
  "reconciliation": "Current source card hash matches campaign snapshot. Historical card did not include S89 fine details. Current card age/hat/early gray temples take precedence over older bare-headed master; preserve remaining master identity and garment palette. Parent confirmed this is an appearance update, not identity conflict.",
  "items": [
    {
      "original_path": "design/04_人物/城市人物/人物_KOR-NPC-EV_埃文·行.md",
      "snapshot_path": "sources/character_card.md",
      "sha256": "5352a5def6b57fa353077ae8bd84af5569f0e9193f8444dda9dcd3c2d55ca3e8",
      "role": "current identity card",
      "roster_sha256_matches": true
    },
    {
      "original_path": "Assets/CharacterDesigns/20261013/expressive/evan/evan_revision_raw_imagegen.png",
      "snapshot_path": "sources/identity_reference.png",
      "sha256": "0190ac818604fd792e431a9ee92502a9ef7a449e7144b84313b98f4954bc813a",
      "role": "identity master; actually viewed",
      "roster_sha256_matches": true
    },
    {
      "original_path": "Assets/CharacterDesigns/20261013/expressive/evan/QA-independent.json",
      "snapshot_path": "sources/master_QA.json",
      "sha256": "6c0d3586b98d788684bc310c05a0f4e0ed03fc1242c0e28d3a31c6e3975c1aab",
      "role": "identity master QA; actually read",
      "roster_sha256_matches": true
    },
    {
      "original_path": "Assets/CharacterDesigns/20261013/expressive/evan/manifest.json",
      "snapshot_path": "sources/master_manifest.json",
      "sha256": "773467c91adc35a84eaa024017aa6a60908c39675a9fc48fd0249571efea56e7",
      "role": "historical manifest",
      "roster_sha256_matches": true
    },
    {
      "original_path": "AGENTS.md",
      "snapshot_path": "sources/AGENTS.md",
      "sha256": "6b3f93de90f8db0d55ed7fa3a0599c4034f7e1b171c71e0f0fa396e80967c4f4",
      "role": "project instructions"
    },
    {
      "original_path": "Assets/CharacterDesigns/20261015/native_style_pilot/mara/assets/portrait_v2_74x100.png",
      "snapshot_path": "sources/mara_style_reference.png",
      "sha256": "1028aa37cfd433770fda10f2ff3825db78b19825ef9de0ce61b66d957210edbd",
      "role": "approved style reference only; actually viewed"
    },
    {
      "original_path": "Assets/CharacterDesigns/20261015/native_style_pilot/iwo/candidates/portrait_v1_74x100_candidate.png",
      "snapshot_path": "sources/iwo_style_reference.png",
      "sha256": "22f6cf0443949dca64496a37173515624c3c7be82703addce853b82e0b342cdb",
      "role": "approved style reference only; actually viewed"
    },
    {
      "original_path": "Assets/CharacterDesigns/20261015/native_style_continuation/leiya/candidates/portrait_v2_maxcoverage_74x100_candidate.png",
      "snapshot_path": "sources/leiya_style_reference.png",
      "sha256": "56bffd334de61ecc1ec12c974e63be78f0a80fd42236af5a166b7e58d55ef40f",
      "role": "approved style reference only; actually viewed"
    },
    {
      "original_path": "Assets/CharacterDesigns/20261015/native_style_continuation/tore/candidates/portrait_v1_74x100_candidate.png",
      "snapshot_path": "sources/tore_style_reference.png",
      "sha256": "1a48bd8348f3a529b38c56fa637ee88106ebf5a5a5df265a16c1b18222cd95d1",
      "role": "approved style reference only; actually viewed"
    },
    {
      "original_path": "design/05_主线/城市篇章/台本_CM-KOR_不是你的姓.md",
      "snapshot_path": "sources/story_1.md",
      "sha256": "2d9602fe16015e53ad7d0eb7ede5ff00adf3ca2454b278a951067d0f9dd870fb",
      "role": "current story; relevant passages inspected"
    },
    {
      "original_path": "design/11_管理/考德与柏石关人物演出审查.md",
      "snapshot_path": "sources/story_2.md",
      "sha256": "8442ef039b6188860053653f12c89278e80eba64a9f455de47744e6e2d2f4d9e",
      "role": "current story; relevant passages inspected"
    },
    {
      "original_path": "design/04_人物/人物细描与随身物.md",
      "snapshot_path": "sources/story_3.md",
      "sha256": "a6a75160713defa2b61b37ab7d0c2f6d677c29ddc9ed2af5894714bc500fc1df",
      "role": "current story; relevant passages inspected"
    },
    {
      "original_path": "Assets/CharacterDesigns/20261013/expressive/evan/spec_lock.json",
      "snapshot_path": "sources/historical_spec_lock.json",
      "sha256": "54f9fa50ea3ca323a8cd76284167c0866c7684763bbf2e9549cee311725e8520",
      "role": "documents older card without S89 appearance additions"
    }
  ]
}


## 产物边界
74×100透明RGBA、临时可见色≤32、alpha仅0/255；大面部短颈窄领。实质绘制仅imagegen，初稿+至多一次修订。整图等比NEAREST、无抖动限色与alpha阈值仅技术派生；不宣称原生逐像素终稿。未改源卡母图代码，不commit/push。
